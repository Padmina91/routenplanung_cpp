var searchData=
[
  ['remove_46',['remove',['../class_queue.html#a687d2502b93c0f30c0df0f03becc3a5c',1,'Queue']]],
  ['remove_5fentry_5fat_47',['remove_entry_at',['../class_queue.html#ae9a481ea2cf25f9a530eccc2b52d74f8',1,'Queue']]]
];
