var searchData=
[
  ['num_5fof_5fentries_5falive_138',['num_of_entries_alive',['../class_entry.html#a6c5bc14cdb9652d84f72ef7e72de52ea',1,'Entry']]],
  ['num_5fof_5fqueues_5falive_139',['num_of_queues_alive',['../class_queue.html#a6ffabf357bd408a0e3137f2e7521fb56',1,'Queue']]]
];
