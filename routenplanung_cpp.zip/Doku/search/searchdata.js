var indexSectionsWithContent =
{
  0: "_acdegimnopqrstv~",
  1: "eiqtv",
  2: "emqt",
  3: "acdegimopqrst~",
  4: "_n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

