var searchData=
[
  ['change_5fpriority_8',['change_priority',['../class_queue.html#a66756eba1eba8b1e70497afa47db9005',1,'Queue']]]
];
